package com.flp.pms.view;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;


public class Saveservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean flag=false;
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		
		response.getWriter();
		IProductService iProductService=new ProductServiceImpl();
		String productName=request.getParameter("pname");
		String proddesc=request.getParameter("pdes");
		String manfacDate=request.getParameter("pmafdate");
		String expDate=request.getParameter("pexdate");
		String mrp=request.getParameter("mrp");
		String catName=request.getParameter("cat");
		String subcatName=request.getParameter("subcat");
		String suppName=request.getParameter("supp");
		String DisName[]=request.getParameterValues("dis");
		String Quantity=request.getParameter("qty");
		String rating=request.getParameter("rating");
		//Date mandate=new Date(manfacDate);
		//Date expdate=new Date(expDate);
		List<Category> categories=iProductService.getAllCategory();
		Category category=new Category();
		for(Category cat:categories){
			if(cat.getCategory_Name().equalsIgnoreCase(catName)){
				category=cat;
			}
		}
		List<SubCategory> subCategories=iProductService.getAllSubCategory();
		SubCategory subCategory=new SubCategory();
		for(SubCategory sub:subCategories){
			if(sub.getSubCategory_Name().equalsIgnoreCase(subcatName)){
				subCategory=sub;
			}
		}
		List<Supplier> suppliers=iProductService.getAllSuppliers();
		Supplier supplier=new Supplier();
		for(Supplier sup:suppliers){
			if(sup.getFirst_Name().equalsIgnoreCase(suppName)){
				supplier=sup;
			}
		}
		List<Discount> discounts=iProductService.getAllDiscounts();
		List<Discount> discount=new ArrayList<>();
		int len=DisName.length;
		int i=0;
		//Discount discount=new Discount();
		for(Discount dis:discounts){
			if(i<len){
			if(dis.getDiscount_Name().equalsIgnoreCase(DisName[i])){
				discount.add(dis);
				i++;
			}
			}
		}
		Product product=new Product();
		product.setProduct_Name(productName);
		product.setDescription(proddesc);
		try {
			product.setManufacturing_Date(sdf.parse(manfacDate));
			product.setExpiry_Date(sdf.parse(expDate));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		product.setMaximum_Retail_Price(Double.parseDouble(mrp));
		product.setCategory(category);
		product.setSubCategory(subCategory);
		product.setSupplier(supplier);
		product.setDiscounts(discount);
		product.setQuantity(Integer.parseInt(Quantity));
		product.setRating(Float.parseFloat(rating));
		 flag=iProductService.addProduct(product);
		 if(flag){
			 response.sendRedirect("pages/success.html");
		 }else
			 response.sendRedirect("pages/error.html");
		
		
	}

}
