package com.flp.pms.domain;

public class SubCategory {
	
	private int sub_category_ID;
	private String sub_category_Name;
	private Category category_ID;
	
	public SubCategory(){}
	
	
	public SubCategory(int sub_category_ID, String sub_category_Name, Category category_ID) {
		super();
		this.sub_category_ID = sub_category_ID;
		this.sub_category_Name = sub_category_Name;
		this.category_ID = category_ID;
	}
	public int getSub_category_ID() {
		return sub_category_ID;
	}
	public void setSub_category_ID(int sub_category_ID) {
		this.sub_category_ID = sub_category_ID;
	}
	public String getSub_category_Name() {
		return sub_category_Name;
	}
	public void setSub_category_Name(String sub_category_Name) {
		this.sub_category_Name = sub_category_Name;
	}
	public Category getCategory_ID() {
		return category_ID;
	}
	public void setCategory_ID(Category category_ID) {
		this.category_ID = category_ID;
	}
	@Override
	public String toString() {
		return "SubCategory [sub_category_ID=" + sub_category_ID + ", sub_category_Name=" + sub_category_Name
				+ ", category_ID=" + category_ID + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category_ID == null) ? 0 : category_ID.hashCode());
		result = prime * result + sub_category_ID;
		result = prime * result + ((sub_category_Name == null) ? 0 : sub_category_Name.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SubCategory other = (SubCategory) obj;
		if (category_ID == null) {
			if (other.category_ID != null)
				return false;
		} else if (!category_ID.equals(other.category_ID))
			return false;
		if (sub_category_ID != other.sub_category_ID)
			return false;
		if (sub_category_Name == null) {
			if (other.sub_category_Name != null)
				return false;
		} else if (!sub_category_Name.equals(other.sub_category_Name))
			return false;
		return true;
	}
	
	

}
