package com.flp.pms.test;

import static org.junit.Assert.*;
import org.junit.Test;

public class ProductServiceImplTestcase {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
