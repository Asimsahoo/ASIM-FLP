package com.flp.pms.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public class ProductServiceImpl implements IProductService
{

	private IProductDao iProductDao = new ProductDaoImplForMap();

	public List<Category> getAllCategory() {
		return iProductDao.getAllCategory();
	}

	public List<SubCategory> getAllSubCategory() {
		return iProductDao.getAllSubCategory();
	}

	public List<Supplier> getAllSuppliers() {
		return iProductDao.getAllSuppliers();
	}
	
    public List<Discount> getAllDiscounts() {
		return iProductDao.getAllDiscounts();
	}

	public void addProduct(Product product) {
		Map<Integer, Product> maps=iProductDao.getAllProducts();
		boolean flag=false;
		Set<Integer> product_IDS = maps.keySet();
		int product_id_generated = generateProductId();
		
		//Generate unique Product Id
		if(!maps.isEmpty()){
			do{
				
				product_id_generated=generateProductId();
				for(Integer product_Id:product_IDS){
					if(product_Id==product_id_generated){
						flag=true;
						break;
					}
				}
			}while(flag);
			
		}
		product.setProduct_ID(product_id_generated);
		
		iProductDao.addProduct(product);
	}

	public int generateProductId(){
		return (int)(Math.random()*10000);
	}

	public Map<Integer, Product> getAllProducts() {
		
		return iProductDao.getAllProducts();
	}

	public List<Product> getAllProductsList() {
		Collection<Product> collectionProduct = getAllProducts().values();
		List<Product> listProducts = new ArrayList<Product>();
		for (Product product : collectionProduct)
			listProducts.add(product);
		return listProducts;
	}

	//Search Product By Product Name
	public Product searchByProductName(String product_Name) {
		List<Product> products = getAllProductsList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getProduct_Name().equalsIgnoreCase(product_Name)) {
				searchedProduct = product;
			}
		}
		return searchedProduct;
	}

	//Search Product By Supplier Name
	public Product searchBySupplierName(String supplierName) {
		List<Product> products = getAllProductsList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getSupplier().getFirst_Name().equalsIgnoreCase(supplierName)
					|| product.getSupplier().getLast_Name().equalsIgnoreCase(supplierName)) {
				searchedProduct = product;
			}
		}
		return searchedProduct;
	}

	//Search Product By Category Name
	public Product searchByCategoryName(String category_Name) {
		List<Product> products = getAllProductsList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getCategory().getCategory_Name().equalsIgnoreCase(category_Name)) {
				searchedProduct = product;
			}
		}
		return searchedProduct;
	}
	
	//Search Product By Sub Category Name
	public Product searchBySubCategoryName(String sub_Category_Name) {
		List<Product> products = getAllProductsList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getSub_Category().getSub_Category_Name().equalsIgnoreCase(sub_Category_Name)) {
				searchedProduct = product;
			}
		}
		return searchedProduct;
	}

	//Search Product By Product Rating
	public Product searchByRating(float ratings) {
		List<Product> products = getAllProductsList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getRatings() == ratings) {
				searchedProduct = product;
			}
		}
		return searchedProduct;
	}

	//Remove Product
	public boolean removeProduct(int product_ID) {
		List<Product> products = getAllProductsList();
		Map<Integer, Product> searchedProduct = getAllProducts();
		for (Product product : products) {
			if (product.getProduct_ID() == product_ID) {
				if (searchedProduct.remove(product.getProduct_ID(), product))
					return true;
			}
		}
		return false;

	}

	//Search Product ID
	public Product searchProductId(int product_ID) {

		List<Product> products = getAllProductsList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getProduct_ID() == product_ID) {
				searchedProduct = product;
			}
		}
		return searchedProduct;

	}

	//Update Product Name
	public Map<Integer, Product> updateProductName(Product p, String pName) {
		Map<Integer, Product> map = getAllProducts();
		p.setProduct_Name(pName);
		map.put(p.getProduct_ID(), p);
		System.out.println("Successfully Updated");
		return map;

	}

	//Update Product Maximum Retail Price
	public Map<Integer, Product> updateProductMaxRetailPrice(Product p, double max) {
		Map<Integer, Product> map = getAllProducts();
		p.setMax_retail_price(max);
		map.put(p.getProduct_ID(), p);
		System.out.println("Successfully Updated");
		return map;

	}

	//Update Product Expiry Date
	public Map<Integer, Product> updateProductExpDate(Product p, Date expiryD) {
		Map<Integer, Product> map = getAllProducts();
		p.setExpiry_Date(expiryD);
		map.put(p.getProduct_ID(), p);
		System.out.println("Successfully Updated");
		return map;
	}

	//Update Product Rating
	public Map<Integer, Product> updateProductRating(Product p, float ratings) {
		Map<Integer, Product> map = getAllProducts();
		p.setRatings(ratings);
		map.put(p.getProduct_ID(), p);
		System.out.println("Successfully Updated");
		return map;
	}

	//Update Product Category
	public Map<Integer, Product> updateProductCategory(Product p, Category category) {
		Map<Integer, Product> map = getAllProducts();
		p.setCategory(category);
		map.put(p.getProduct_ID(), p);
		System.out.println("Successfully Updated");
		return map;

	}
}
