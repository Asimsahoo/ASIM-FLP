package com.flp.pms.domain;

import java.util.Date;

public class Discount 
{

	//Discount Instance Variables
	private int discount_ID;
	private String discount_Name;
	private String description;
	private double discount_percentage;
	private Date valid_thru;
	
	//No Arguments Constructor
	public Discount()
	{
		
	}

	//Full Arguments Constructor
	public Discount(int discount_ID, String discount_Name, String description, double discount_percentage,
			Date valid_thru) 
	{
		super();
		this.discount_ID = discount_ID;
		this.discount_Name = discount_Name;
		this.description = description;
		this.discount_percentage = discount_percentage;
		this.valid_thru = valid_thru;
	}

	            //Public Getters & Setters
				public int getDiscount_ID() {
					return discount_ID;
				}
			
				public void setDiscount_ID(int discount_ID) {
					this.discount_ID = discount_ID;
				}

				public String getDiscount_Name() {
					return discount_Name;
				}
			
				public void setDiscount_Name(String discount_Name) {
					this.discount_Name = discount_Name;
				}

				public String getDescription() {
					return description;
				}
			
				public void setDescription(String description) {
					this.description = description;
				}

				public double getDiscount_percentage() {
					return discount_percentage;
				}
			
				public void setDiscount_percentage(double discount_percentage) {
					this.discount_percentage = discount_percentage;
				}

				public Date getValid_thru() {
					return valid_thru;
				}
			
				public void setValid_thru(Date valid_thru) {
					this.valid_thru = valid_thru;
				}

	//To String()
	@Override
	public String toString() 
	{
		return "Discount [discount_ID=" + discount_ID + ", discount_Name=" + discount_Name
							+ ", description=" + description + ", discount_percentage=" + discount_percentage
							+ ", valid_thru=" + valid_thru + "]";
				}

	//HashCode()
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + discount_ID;
		result = prime * result + ((discount_Name == null) ? 0 : discount_Name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(discount_percentage);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((valid_thru == null) ? 0 : valid_thru.hashCode());
		return result;
	}

	//Equals()
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Discount other = (Discount) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (discount_ID != other.discount_ID)
			return false;
		if (discount_Name == null) {
			if (other.discount_Name != null)
				return false;
		} else if (!discount_Name.equals(other.discount_Name))
			return false;
		if (Double.doubleToLongBits(discount_percentage) != Double.doubleToLongBits(other.discount_percentage))
			return false;
		if (valid_thru == null) {
			if (other.valid_thru != null)
				return false;
		} else if (!valid_thru.equals(other.valid_thru))
			return false;
		return true;
	}
	
}
