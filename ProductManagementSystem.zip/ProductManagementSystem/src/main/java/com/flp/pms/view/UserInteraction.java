package com.flp.pms.view;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.util.Validate;

public class UserInteraction 
{

	@SuppressWarnings("deprecation")
	public Product addProduct(List<Category> categories, List<SubCategory> subCategories,
			 List<Supplier> suppliers, List<Discount> discounts)
	{
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		boolean flag = false;
		Product product = new Product();
		
		//Promt Valid Product Name
		String product_Name;
		do
		{
			System.out.println("Enter Product Name : ");
			product_Name = sc.nextLine();
			flag = Validate.isValidProductName(product_Name);
			
			if(!flag)
				System.out.println("Invalid Product Name!");
		}
		  while(!flag);
		  product.setProduct_Name(product_Name);
				
		
		 //Promt Product Description
		
			System.out.println("Enter Product Description : ");
			String description = sc.nextLine();
			product.setDescription(description);
			
	    
		//Promt Valid Manufacturing Date
	    String manufacturing_Date;
		do
		{
			System.out.println("Enter Manufacturing Date [dd-MMM-yyyy] : ");
			manufacturing_Date = sc.nextLine();
			flag = Validate.isValidDate(manufacturing_Date);
					
			if(!flag)
				System.out.println("Invalid Manufacturing Date!");
			}
		    while(!flag);
			product.setManufacturing_Date(new Date(manufacturing_Date));
		
			
	    //Promt Valid Expiry Date
	    String expiry_Date;
	    do
		{
			System.out.println("Enter Expire Date [dd-MMM-yyyy] : ");
			expiry_Date = sc.nextLine();
			flag = Validate.isValidDate(expiry_Date);
							
		    if(!flag)
				System.out.println("Invalid Expiry Date!");
			}
			while(!flag);
			product.setExpiry_Date(new Date(expiry_Date));
		

		//Promt Maximum Retail Price
			
		System.out.println("Enter Maximum Retail Price : ");
		double max_retail_price = sc.nextDouble();
		product.setMax_retail_price(max_retail_price);
				
		
		//Promt Product Quantity
		
		int quantity = 0;
		do
		{
		System.out.println("Enter Product Quantity : ");
		quantity = sc.nextInt();
		flag = Validate.isValidQuantity(quantity);
		
		if(!flag)
				System.out.println("* Qunaity Should be positive integer!");
		}while(!flag);
		product.setQuantity(quantity);
		
		
		//prompt Ratings
		
		float ratings = 0.0f;
		do
		{
		System.out.println("Enter Product Ratings : ");
		ratings = sc.nextFloat();
		flag=Validate.isValidRatings(ratings);
		
		if(!flag)
				System.out.println("* Ratings Should be between 1.0 and 5.0!");
		}while(!flag);
		product.setRatings(ratings);
		
		
		//prompt valid category object
		Category category = getCategory(categories);
		product.setCategory(category);
		
		//Prompt SubCategory Details
		SubCategory subCategory=getSubCategory(subCategories, category);
		product.setSub_Category(subCategory);
	
		//Prompt Dicsount Details
		List<Discount> discounts2=getDiscounts(discounts);
		product.setDiscounts(discounts2);
		
		//Prompt Supplier Details
		Supplier supplier=getSupplier(suppliers);
		product.setSupplier(supplier);
		
		return product;
	}
	
	//Choose Category
	public Category getCategory(List<Category> categories)
	{
		
		Category category=null;
		boolean flag=false;
		
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		int choice;	
		
		do{
			System.out.println("Choose Catgeory Id:");
			for(Category category1:categories)
				System.out.println(category1.getCategory_ID() +"\t" +category1.getCategory_Name() +
						"\t"+category1.getDescription());
			choice=sc.nextInt();
			
			
			//Validate the Category
			for(Category category1:categories){
				if(choice==category1.getCategory_ID())
				{
					category=category1;
					flag=true;
					break;
				}
			}
			if(!flag)
				System.out.println("* Please choose Valid Category ID!");
		}while(!flag);
		
		return category;
	}	

	//Choose Sub Category
	public SubCategory getSubCategory(List<SubCategory> categories,Category category)
		{
			SubCategory subCategory = null;
			@SuppressWarnings("resource")
			Scanner scanner = new Scanner(System.in);
			int option;
			boolean flag = false;
			
			do{
				System.out.println("Choose Product Sub Category:");
				for(SubCategory  subCategory2:categories){
					if(subCategory2.getCategory_ID().getCategory_ID()==category.getCategory_ID())
						System.out.println(subCategory2.getSub_Category_ID()   + "\t" 
					                      +subCategory2.getSub_Category_Name() + "\t" 
					                          +category.getCategory_ID()       + "\t" 
					                          +category.getCategory_Name()     + "\t" 
					                          +category.getDescription());
						}
				option=scanner.nextInt();
				
				
		//Check Valid SubCategory
		for(SubCategory subCategory2:categories){
		if(option==subCategory2.getSub_Category_ID())
				{
				  subCategory=subCategory2;
				  flag=true;
				  break;
				}
			}
				
				if(!flag)
					System.out.println("* Please choose valid Sub category!");
			
			}while(!flag);
			
			return subCategory;
		}
		
	//Choose Suppliers
	private Supplier getSupplier(List<Supplier> suppliers) 
		{
			Supplier supplier=null;
			boolean flag=false;
			
			@SuppressWarnings("resource")
			Scanner sc=new Scanner(System.in);
			int choice;	
			
			do{
				System.out.println("Choose Supplier Id:");
				for(Supplier supplier1:suppliers)
					System.out.println(supplier1.getSupplier_ID() + "\t" 
				                      +supplier1.getFirst_Name()  + "\t" 
							          +supplier1.getLast_Name()   + "\t" 
							          +supplier1.getAddress()     + "\t" 
							          +supplier1.getCity()        + "\t" 
							          +supplier1.getState()       + "\t" 
							          +supplier1.getPinCode()     + "\t" 
							          +supplier1.getContact_Number());
				choice=sc.nextInt();
				
				//Validate the Supplier
				for(Supplier supplier1:suppliers){
					if(choice==supplier1.getSupplier_ID())
					{
						supplier=supplier1;
						flag=true;
						break;
					}
				}
				if(!flag)
					System.out.println("* Please choose Valid Supplier ID!");
			}while(!flag);
			return supplier;
		}

	//Choose Discounts
	public List<Discount> getDiscounts(List<Discount> discounts)
		
		{
			List<Discount> discounts2 = new ArrayList<Discount>();
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			int option = 0;
			boolean flag = false;
			String choice = null;
			
			
			do{
				flag=false;
				do{
					System.out.println("Choose Dicounts for the Product:");
					for(Discount discount:discounts){
		//check valid discounts
				if(discount.getValid_thru().after(new Date())){
				//System.out.println(discount.getValidThru());
				System.out.println(discount.getDiscount_ID() + "\t" 
								+discount.getDiscount_ID() + "\t"
								+discount.getDescription() +"\t"
								+discount.getDiscount_percentage());
						}
								
					}
					option=sc.nextInt();
					
					
		//Validate Discount
				L3:	for(Discount discount:discounts){
						if(discount.getDiscount_ID()==option)
						{
							discounts2.add(discount);
							flag=true;
							break L3;
						}
					}
					
					if(!flag)
						System.out.println("* Choose Valid Discount Id!");
					
				}while(!flag);
				
				System.out.println("You wish to add more discounts for this product?[Y|N]");
				choice=sc.next();
				
			}while(choice.charAt(0)=='y' || choice.charAt(0)=='Y');
			
			return discounts2;
		}
		
	//Show Searched Product
	public void showSearchedProduct(Product searchedProduct) {
			if (searchedProduct != null)
				System.out.println(searchedProduct);
			else
				System.out.println("Product not found.");

		}

	//Search By Product Name
	public String getProductName() {
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter product name: ");
			String product_Name = sc.nextLine();
			return product_Name;
		}

	//Search By Supplier Name
	public String getSupplierName() {
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter supplier name: ");
			String supplierName = sc.nextLine();
			return supplierName;
		}

	//Search By Category Name
	public String getCategoryName() {
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter category name: ");
			String category_Name = sc.nextLine();
			return category_Name;
		}

	//Search By Sub Category Name
	public String getSubCategoryName() {
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter sub-category name: ");
			String sub_Category_Name = sc.nextLine();
			return sub_Category_Name;
		}

	//Search By ratings
	public float getRatings() {
			float ratings = 0.0f;
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			boolean flag = false;
			do {
				System.out.println("Enter Product Ratings:");
				ratings = sc.nextFloat();
				flag = Validate.isValidRatings(ratings);
				if (!flag)
					System.out.println("* Ratings Should be between 1.0 and 5.0!");
			} while (!flag);
			return ratings;
		}

	//View All Products
	public void viewAllProduts(List<Product> listOfProducts) {
			if (!listOfProducts.isEmpty()) {
				for (Product product : listOfProducts)
					System.out.println(product);
			} else {
				System.out.println("No produts available to show.");
			}

		}

	//Search Product ID
	public int getProduct_ID() {
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Product Id: ");
			int product_ID = sc.nextInt();
			return product_ID;
		}

	//Remove Product
	public void getDeleteStatus(boolean removeProduct) {

			if (removeProduct)
				System.out.println("Product removed.");
			else
				System.out.println("Not removed.");

		}

	//Update Product Name
	public String getProductNameForUpdate() {
			String productName;
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			boolean flag = false;
			do {
				System.out.println("Enter ProductName:");
				productName = sc.nextLine();
				flag = Validate.isValidProductName(productName);
				if (!flag)
					System.out.println("* Invalid ProductName!");
			} while (!flag);
			return productName;
		}

	//Update Product Expiry Date 
	@SuppressWarnings("deprecation")
    public Date getProductExDateForUpdate() {
			String expiry_Date;
			boolean flag = false;
			boolean ex_flag = false;
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			do {

				// Validate Date Format
				do {
					System.out.println("Enter Expiry Date:[dd-MMM-yyyy]");
					expiry_Date = sc.next();
					flag = Validate.isValidDate(expiry_Date);
					if (!flag)
						System.out.println("* Invalid Date Format!");

				} while (!flag);

				ex_flag = Validate.isValidExpiryDate(new Date(expiry_Date));

				if (!ex_flag)
					System.out.println("* Expiry Date must be future Date!");
			} while (!ex_flag);
			return new Date(expiry_Date);
		}

	//Update Product Maximum Retail Price
	public double getProductMaxRetailPriceForUpdate() {
			double price;
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Maximum Retail Price:");
			price = sc.nextDouble();
			return price;
		}

	//Update Product Ratings
	public float getProductRatingForUpdate() {
			float ratings = 0.0f;
			boolean flag = false;
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			do {
				System.out.println("Enter Product Ratings:");
				ratings = sc.nextFloat();
				flag = Validate.isValidRatings(ratings);
				if (!flag)
					System.out.println("* Ratings Should be between 1.0 and 5.0!");
			} while (!flag);
			return ratings;
		}
}
