package com.flp.pms.view;

import java.sql.Date;
import java.util.Scanner;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.flp.pms.domain.Category;

public class BootClass {

	public static void main(String[] args) 
	{
	   menuSelection();
	}

	public static void menuSelection()
	{
	
		int option;
		String choice = null;
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		UserInteraction userInteraction = new UserInteraction();
		IProductService iProductService = new ProductServiceImpl();
		
		do
		{
		System.out.println("1.Create Product"+
		                 "\n2.Modify Product"+
				         "\n3.Remove Product"+
		                 "\n4.View All Product"+
				         "\n5.Search Product"+
		                 "\n6.Exit");
		
		System.out.println("Enter Your Option");
		option = sc.nextInt();
		
		switch(option)
		{
		
		        //To Create A Product
				case 1:
					
					Product product = userInteraction.addProduct(iProductService.getAllCategory(),
							iProductService.getAllSubCategory(),
							iProductService.getAllSuppliers(),
							iProductService.getAllDiscounts());
							
					iProductService.addProduct(product);
					System.out.println(product);
					
					break;
				
				//To Update Product
				case 2:

					int pId = userInteraction.getProduct_ID();
					Product p = iProductService.searchProductId(pId);
					if (p != null) {
						System.out.println("1.By Product Name" + "\n2.By Expiry Date" + "\n3. By Maximum Retail Price"
								+ "\n4.By Rating" + "\n5.By Category");
						System.out.println("Enter your option:");
						option = sc.nextInt();
						
						switch (option) 
						{
						
						//Update Product Name
						case 1:
							String pName = userInteraction.getProductNameForUpdate();
							iProductService.updateProductName(p, pName);
							break;
						
					    //Update Product Expiry Date
						case 2:
							Date expiryD = (Date) userInteraction.getProductExDateForUpdate();
							iProductService.updateProductExpDate(p, expiryD);
							break;
						
						//Update Product Maximum Retail Price
						case 3:
							double max = userInteraction.getProductMaxRetailPriceForUpdate();
							iProductService.updateProductMaxRetailPrice(p, max);
							break;

						//Update Product Rating
						case 4:
							float rating = userInteraction.getProductRatingForUpdate();
							iProductService.updateProductRating(p, rating);
							break;
						
					    //Update Category 
						case 5:
							Category category = userInteraction.getCategory(iProductService.getAllCategory());
							iProductService.updateProductCategory(p, category);
							break;
						}
					} else {
						System.out.println("Product Id not found");
					}
					break;
					
				//To Delete A Product	
				case 3:
					int productId = userInteraction.getProduct_ID();
					Product productToRemove = iProductService.searchProductId(productId);
					if (productToRemove != null) {
						userInteraction.getDeleteStatus(iProductService.removeProduct(productId));
					} else {
						System.out.println("Product Id not found");
					}

					break;
				
			    //To View All Products
				case 4:
					System.out.println(iProductService.getAllProducts());
					break;
					
				//To Search A Product
				case 5:
					System.out.println("1.By Name"+
							         "\n2.By Supplier"+
							         "\n3.By Category"+
							         "\n4.By SubCategory"+
							         "\n5.By Ratings");
					System.out.println("Enter your option");
					option = sc.nextInt();
					Product searchedProduct = null;
					switch (option) 
					{
				
				//Search By Product Name	
				case 1:
					String productName = userInteraction.getProductName();
					searchedProduct = iProductService.searchByProductName(productName);
					userInteraction.showSearchedProduct(searchedProduct);
				    break;
				
				//Search By Supplier Name
				case 2:
					String supplierName = userInteraction.getSupplierName();
					searchedProduct = iProductService.searchBySupplierName(supplierName);
					userInteraction.showSearchedProduct(searchedProduct);
					break;

				//Search By Category Name
				case 3:
					String categoryName = userInteraction.getCategoryName();
					searchedProduct = iProductService.searchByCategoryName(categoryName);
					userInteraction.showSearchedProduct(searchedProduct);
					break;
				
				//Search By Sub Category Name
				case 4:
					String subCategoryName = userInteraction.getSubCategoryName();
					searchedProduct = iProductService.searchBySubCategoryName(subCategoryName);
					userInteraction.showSearchedProduct(searchedProduct);
					break;
				
				//Search By Product Name
				case 5:
					float rating = userInteraction.getRatings();
					searchedProduct = iProductService.searchByRating(rating);
					userInteraction.showSearchedProduct(searchedProduct);
					break;
					
				default:
					System.out.println("Invalid input");
					break;
					}
					
					break;
				
				//Exit
				case 6:
					System.exit(0);
					break;
	}
		System.out.println("You wish to continue?[Y|N]");
		choice = sc.next();
	}
		while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			
		

	}
}