package com.flp.pms.domain;

public class SubCategory 
{

	//Sub Category Instance Variables
	private int sub_Category_ID;
	private String sub_Category_Name;
	private Category category_ID;
	
	//No Arguments Constructor
	public SubCategory()
	{
		
	}
	
	//Full Arguments Constructor
	public SubCategory(int sub_Category_ID, String sub_Category_Name, Category category_ID) 
	{
		super();
		this.sub_Category_ID = sub_Category_ID;
		this.sub_Category_Name = sub_Category_Name;
		this.category_ID = category_ID;
	}

	        //Public Getters & Setters
			public int getSub_Category_ID() {
				return sub_Category_ID;
			}
		
			public void setSub_Category_ID(int sub_Category_ID) {
				this.sub_Category_ID = sub_Category_ID;
			}
		
			public String getSub_Category_Name() {
				return sub_Category_Name;
			}
		
			public void setSub_Category_Name(String sub_Category_Name) {
				this.sub_Category_Name = sub_Category_Name;
			}
		
			public Category getCategory_ID() {
				return category_ID;
			}
		
			public void setCategory_ID(Category category_ID) {
				this.category_ID = category_ID;
			}

	//To String()
	@Override
	public String toString() 
	{
		return "SubCategory [sub_Category_ID=" + sub_Category_ID + ", sub_Category_Name=" + sub_Category_Name
						+ ", category_ID=" + category_ID + "]";
			}

	//Hashcode() & Equals()
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category_ID == null) ? 0 : category_ID.hashCode());
		result = prime * result + sub_Category_ID;
		result = prime * result + ((sub_Category_Name == null) ? 0 : sub_Category_Name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SubCategory other = (SubCategory) obj;
		if (category_ID == null) {
			if (other.category_ID != null)
				return false;
		} else if (!category_ID.equals(other.category_ID))
			return false;
		if (sub_Category_ID != other.sub_Category_ID)
			return false;
		if (sub_Category_Name == null) {
			if (other.sub_Category_Name != null)
				return false;
		} else if (!sub_Category_Name.equals(other.sub_Category_Name))
			return false;
		return true;
	}
	
	
}
