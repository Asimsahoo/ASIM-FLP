package com.flp.pms.util;

import java.util.Date;

public class Validate 
{
    
	//Product Name Validation
	public static boolean isValidProductName(String product_Name)
	{
		return product_Name.matches("[A-Z][A-Za-z1-9_$ ]*");
	}
	
	//Date Validation
	public static boolean isValidDate(String givenDate)
	{
		return givenDate.matches("([0][0-9]|[1-2]\\d{1}|[30|31])-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][7890]\\d{2}");
	}
	
	//Expiry Date Validation
	public static boolean isValidExpiryDate(Date expiry_Date)
	{
		return expiry_Date.after(new Date());
	}
	
	//Ratings Validation
	public static boolean isValidRatings(float ratings)
	{
		if(ratings >= 0.0 && ratings <= 5.0)
			return true;
		else
			return false;
	}
	
	//Contact Number Validation
	public static boolean isValidContactNumber(String contact_Number)
	{
		return contact_Number.matches("\\d{10}");
	}

	//Quantity Validation
	public static boolean isValidQuantity(int quantity) 
	{
		return quantity > 0;
	}
	
}
